# Application to manage a Music Studio

Designed with Java and MySql
This application can store music details like author, title, number of records till date etc. 
Application maintains a database in SQL.
User Interface made using Java utilities
